#include <stdio.h>
#include <stdlib.h>

int main() {
    
    //declarar variables
    double peso, altura;
    int edad;
    char inicial;
    
    //Ingresar la altura
    printf("Por favor, introduce la altura en cm: ");
    scanf("%lf", &altura);
    
    //Ingresar la edad    
    printf("A continuación, introduce la edad en años: ");
    scanf("%d", &edad);
    
    //Ingresar la inicial    
    printf("Por último, introduce la inicial del nombre: ");
    scanf("\n%c", &inicial);
    
    //Formula de Perroult
    peso = altura - 100 + (9*(double)edad)/100.0; 
    
    //Mostrar resultado
    printf("El peso ideal de %c, que mide %0.1lf cm y tiene %d años es de %0.3lf kg.", inicial, altura, edad, peso);  

    //Salida correcta
    return 0;
}