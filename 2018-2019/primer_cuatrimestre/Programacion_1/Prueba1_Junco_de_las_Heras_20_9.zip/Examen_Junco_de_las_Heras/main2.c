#include <stdio.h>
#include <stdlib.h>

int main() {
    
    //Declarar variables
    int num;
    char letra1, letra2;
    
    //Ingresar el numero
    printf("Por favor, introduce un número (entre 1 y 5): ");
    scanf("%d", &num);

    //Ingresar la letra    
    printf("Por favor, introduce un carácter: ");
    scanf("\n%c", &letra1);
    
    //Conversion
    letra2=letra1+num;
    
    //Resultado
    printf("El carácter %c con código ASCII %d, si se cifra con el número %d se convertiría en el carácter %c con el código ASCII %d", letra1, letra1, num, letra2, letra2);
  
    //Salida correcta
    return 0;
}