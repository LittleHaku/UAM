Autor: Junco de las Heras Valenzuela junco.heras@estudiante.uam.es
Grupo: 2301, Doble Grado.

La entrega son dos carpetas, una que reune los ejercicios 1 y 2 y luego
una carpeta con el ejercicio 3, que aunque incluye las funcionalidades anteriores,
se incluye ya que se ha modificado los ficheros.

En el ejercicio 3 se han implementado y testeado todos los apartados.

Notese que para mover la serpiente se usan las teclas 'w','a','s','d','i','j','k','l','q' minusculas
pero a veces el propio DOSBOX tiene problemas en que se fijan las mayusculas.