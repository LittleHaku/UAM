function I = int_S(a,b,fa,fc,fb)

I = (fa+4*fc+fb)*(b-a)/6;