function I = int_T(a,b,fa,fb)

I = (fa+fb)*(b-a)/2;