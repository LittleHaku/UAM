function I = int_R(a,b,fa)

I = fa*(b-a);