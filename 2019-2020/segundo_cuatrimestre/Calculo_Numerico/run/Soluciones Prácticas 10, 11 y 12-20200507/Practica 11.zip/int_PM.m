function I = int_PM(a,b,fc)

I = fc*(b-a);