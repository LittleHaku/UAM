function [c] = diferenciasHermite(nodos,valores, derivadas)
  
    n = length(nodos);
    c = valores;
    %lo unico que cambia es que en la primera iteracion de la i, cuando
    %i==2, los f[xi, xi] son la derivada, y no la diferencia dividida
    for j = n:-1:2
        if mod(j,2) == 1
            c(j) = (c(j) -c(j-1))./(nodos(j) - nodos(j-2+1));
        else
            c(j) = derivadas(j/2);
        end
    end
    %igual que en las diferencias divididas simples
    for i = 3:1:n
        for j = n:-1:i
            c(j) = (c(j) -c(j-1))./(nodos(j) - nodos(j-i+1));
        end
    end
end