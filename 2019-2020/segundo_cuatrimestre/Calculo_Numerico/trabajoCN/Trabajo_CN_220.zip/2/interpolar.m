nodos = input("Introduce los nodos: ");

n = length(nodos);
xmin = min(nodos);
xmax = max(nodos);

nodos = zeros(1,2*n);
valores = nodos;
derivadas = zeros(1,n);
interval = linspace(xmin, xmax, n);
%declaras x como variable
syms x;
%la funcion a interpolar
f = @(x) (exp(x)+exp(-x))/2;
%derivada de f
d = eval(['@(x)' char(diff(f(x)))]);

%rellenas valores de nodo y su imagen (f(nodo(i)))
for i = 1:2*n
    nodos(i) = interval(floor((i-1)/2) + 1);
    valores(i) = f(nodos(i));
end
%rellenas valores de la derivada del nodo(i)
for i = 1:n
    derivadas(i) = d(nodos(2*i));
end
%la funcion interpolada
g = @(x) Hermite(nodos, valores,derivadas, x);
%la mitad izquierda la funcion dada si se pone [xmin, 0]
fplot(f, [xmin, xmax])
hold on
%la mitad derecha la funcion interpolada si se pone [0, xmax]
fplot(g, [xmin, xmax])
%vemos los nodos interpolados
plot(nodos, valores, 'r*')
hold off