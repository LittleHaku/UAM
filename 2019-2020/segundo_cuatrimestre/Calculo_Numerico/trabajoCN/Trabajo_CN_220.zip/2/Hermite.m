function [y] = Hermite(nodos, valores, derivadas, x)
    % Hermite
    %parecido a Newton pero llamando a diferenciasHermite
    n = length(nodos);
    c = diferenciasHermite(nodos, valores, derivadas);
    y = c(n);
    for i = n:-1:2
        y = y .* (x - nodos(i-1));
        y = y + c(i-1);
    end
end