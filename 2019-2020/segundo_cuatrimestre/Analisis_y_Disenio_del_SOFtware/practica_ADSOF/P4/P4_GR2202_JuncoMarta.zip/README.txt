Autores: 
Junco de las Heras junco.heras@estudiante.uam.es 
Marta Vaquerizo marta.vaquerizo@estudiante.uam.es

Grupo 2202
Pareja nº 5

Para generar la documentacion:
make generate_doc

Para compilar con la terminal dentro de src:
make compile

Para ejecutar los tests:
make run1
make run2
make run3
make run4
make run5


Directorios:
//El actual documento
README.txt 

//recortes de pantallas mosotrando que las salidas esperadas coinciden con las nuestras
evidencias/*.png

//el enunciado de la practica
practica04.pdf

//Es el PDF con el diagrama pedido y las explicaciones de los apartados
memoriaP4.pdf

//La documentacion de las clases de Java
doc/*

//El codigo fuente
src/*

//El diagrama de clases
diagrama_clases.png




