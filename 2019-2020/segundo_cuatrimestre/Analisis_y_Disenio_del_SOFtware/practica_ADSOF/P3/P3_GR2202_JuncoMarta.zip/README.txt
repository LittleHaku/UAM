Autores: 
Junco de las Heras junco.heras@estudiante.uam.es 
Marta Vaquerizo marta.vaquerizo@estudiante.uam.es

Grupo 2202
Pareja nº 5

Para generar la documentacion:
javadoc -d doc -author src/ads/practica3/*.java src/ads/ejercicio6/*.java

Para compilar con la terminal dentro de src:
javac ads/practica3/*.java ads/ejercicio6/*.java

Para ejecutar con la terminal dentro de src:
java ads.practica3.TesterTienda1
java ads.practica3.TesterTienda2 productos.txt
java ads.practica3.TesterTienda4
java ads.practica3.TesterTienda5
java ads.ejercicio6.TesterTienda6

Directorios:
//El actual documento
README.txt 

//recortes de pantallas mosotrando que las salidas esperadas coinciden con las nuestras
evidencias/*.png

//El archivo para leer los electrodomesticos
productos.txt

//el enunciado de la practica
practica03.pdf

//Es el PDF con el diagrama pedido y las explicaciones de los apartados
memoria.pdf y memoria.odt

//La documentacion de las clases de Java
doc/*

//El codigo fuente
src/ads/*

//Ejercicio 6
src/ads/ejercicio6

//Todos los demas ejercicios
src/ads/practica3


