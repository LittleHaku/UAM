/**
 * Este es la clase HolaMundo
 * 
 * @author Junco de las Heras y Marta Vaquerizo
 * 
 */
public class HolaMundo {
    /**
     * @param args entrada de los argumentos por la linea de comandos
     */
    public static void main(String[] args) {
        System.out.println("Hola mundo");
    }

}
