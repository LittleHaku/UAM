Junco de las Heras junco.heras@estudiante.uam.es 2201 17-03-2020
Marta Vaquerizo marta.vaquerizo@estudiante.uam.es 2201 17-03-2020

Para ejecutar un fichero basta con hacer make run_nombre_fichero o make runv_nombre_fichero si se quiere usar Valgrind.
El makefile hace gcc -Wall -pedantic nombre_fichero && ./a.out, no hace codigo objeto porque no es necesario.
Tambien tiene un clean, que borra los temporales

Listado de los archivo de codigo entregados:

ejercicio_alarm.c
ejercicio_alternar.c
ejercicio_captura.c
ejercicio_captura_mejorado.c
ejercicio_kill.c
ejercicio_lect_escr.c
ejercicio_prottemp.c
ejercicio_prottemp_mejorado.c
ejercicio_prottemp_mejorado_op.c
ejercicio_sem.c
ejercico_sem_signal.c
ejercicio_sigset.c



La memoria esta en formato PDF Memoria.pdf

