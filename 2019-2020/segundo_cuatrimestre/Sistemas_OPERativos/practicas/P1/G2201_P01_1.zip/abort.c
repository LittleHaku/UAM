#include <stdio.h>
#include <stdlib.h>

//main que aborta. Guardese en abort.exe por ejemplo
int main(void)
{
    if(fprintf(stdout, "abortando...\n") <= 0) {
        exit(EXIT_FAILURE);
    }
    abort();
}
