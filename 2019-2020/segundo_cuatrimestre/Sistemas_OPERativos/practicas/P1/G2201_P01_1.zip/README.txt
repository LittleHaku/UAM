Junco de las Heras junco.heras@estudiante.uam.es 2201 16-2-2020
Marta Vaquerizo marta.vaquerizo@estudiante.uam.es 2201 16-2-2020

Para ejecutar un fichero basta con hacer make run_nombre_fichero o make runv_nombre_fichero si se quiere usar Valgrind.
El makefile hace gcc -Wall -pedantic nombre_fichero && ./a.out, no hace codigo objeto porque no es necesario.
Tambien tiene un clean, que borra los temporales

Listado de los archivo de codigo entregados:

ejercicio3.c
ejercicio4.c	
ejemplo_hilos.c	
ejercicio_hilos.c
ejemplo_fork.c	
ejercicio_arbol.c	
ejemplo_malloc.c	
ejercicio_shell.c	
ejercicio_shell_spawn.c	
ejemplo_descriptores.c	
ejemplo_buffer.c	
ejemplo_pipe.c	
ejercicio_pipes.c

abort.c
abort.exe es el ejecutable de abort.c

La memoria esta en formato docx memoria.docx o en formato PDF memoria.pdf

Los archivos de texto (*.txt) estan en archivos_texto_Practica1
