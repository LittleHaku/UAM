Junco de las Heras junco.heras@estudiante.uam.es 2201 07-05-2020
Marta Vaquerizo marta.vaquerizo@estudiante.uam.es 2201 07-05-2020

Listado de los archivo de codigo entregados:

el makefile

global.h
sort.c
sort.h
utils.c
utils.h
main.c

Evidencias:
medidas_data.txt -> medidas tomadas para la gráfica. 

capturas de la ejecución.

diagrama y esquema para que se puedan ampliar.
